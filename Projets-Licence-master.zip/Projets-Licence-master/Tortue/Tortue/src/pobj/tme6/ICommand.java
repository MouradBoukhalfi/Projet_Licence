package pobj.tme6;


public interface ICommand {
	
	public void execute(IColorTurtle turtle);
	
}
