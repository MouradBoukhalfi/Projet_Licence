package pobj.motx.tme2.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ DictionnaireTest.class, DictionnaireTest2.class, GrillePotentielTest.class, GrillePotentielTest2.class,
		GrillePotentielTest3.class, GrillePotentielTest4.class, GrillePotentielTest5.class, GrillePotentielTest6.class })
public class TME2Tests {

}
